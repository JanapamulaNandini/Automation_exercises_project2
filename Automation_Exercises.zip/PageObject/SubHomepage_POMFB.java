package automationexcercise;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class SubHomepage_POMFB {

	@FindBy(css = "#footer > div.footer-widget > div > div > div.col-sm-3.col-sm-offset-1 > div > h2")WebElement subscription;
	@FindBy(id = "susbscribe_email")WebElement email;
	@FindBy(xpath = "//*[@id=\"subscribe\"]/i")WebElement arrowbutton;
}
