package automationexcercise;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;

public class AddProductcart_POMFB {

	@FindBy(xpath = "//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[2]/a")WebElement product;
	@FindBy(xpath = "/html/body/section[2]/div/div/div[2]/div/div[2]/div/div[1]/div[2]")WebElement mouseoverFP1;
	@FindBy(xpath = "/html/body/section[2]/div/div/div[2]/div/div[2]/div/div[1]/div[2]/div/a")WebElement Add2cart1;
	@FindBy(xpath = "//*[@id=\"cartModal\"]/div/div/div[3]/button")WebElement continueshopping;
	@FindBy(xpath = "/html/body/section[2]/div/div/div[2]/div/div[3]/div/div[1]/div[2]")WebElement mouseoverFP2;
	@FindBy(xpath = "/html/body/section[2]/div/div/div[2]/div/div[3]/div/div[1]/div[2]/div/a")WebElement Add2cart2;
	@FindBy(xpath = "//*[@id=\"cartModal\"]/div/div/div[2]/p[2]/a/u")WebElement viewcart;
	@FindBy(xpath = "//*[@id=\"cart_info\"]")WebElement cartproducts;
	@FindBy(xpath = "//*[@id=\"product-1\"]/td[3]/p")WebElement fpp;
	@FindBy(xpath = "//*[@id=\"product-2\"]/td[5]/p")WebElement spp;
	@FindBy(xpath = "//*[@id=\"product-1\"]/td[4]/button")WebElement fpq;
	@FindBy(xpath = "//*[@id=\\\"product-2\\\"]/td[4]/button")WebElement spq;
	@FindBy(xpath = "\"//*[@id=\\\"product-1\\\"]/td[5]/p\"")WebElement fptp;
	@FindBy(xpath = "\"//*[@id=\\\"product-2\\\"]/td[5]/p\"")WebElement sptp;
}
