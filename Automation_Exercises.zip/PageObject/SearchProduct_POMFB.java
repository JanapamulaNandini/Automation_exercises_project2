package automationexcercise;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class SearchProduct_POMFB {
  
	@FindBy(css = "#header > div > div > div > div.col-sm-8 > div > ul > li:nth-child(2) > a")WebElement products;
	@FindBy(id = "search_product")WebElement productname;
	@FindBy(id = "submit_search")WebElement searchbutton;
}
