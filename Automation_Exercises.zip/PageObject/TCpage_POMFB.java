package automationexcercise;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class TCpage_POMFB {
	
    @FindBy(xpath = "//*[@id=\"slider-carousel\"]/div/div[1]/div[1]/a[1]/button")WebElement TC;
    @FindBy(xpath = "/html/body")WebElement TCpage;
	}


