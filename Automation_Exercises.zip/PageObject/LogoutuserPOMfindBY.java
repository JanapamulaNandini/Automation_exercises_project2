package automationexcercise;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class LogoutuserPOMfindBY {

     @FindBy(xpath = "//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[4]/a")WebElement signuplogin;
     @FindBy(name = "email")WebElement email;
     @FindBy(name = "password")WebElement pass;
     @FindBy(xpath = "//*[@id=\"form\"]/div/div/div[1]/div/form/button")WebElement loginbutton;
     @FindBy(xpath = "//*[@id=\\\"header\\\"]/div/div/div/div[2]/div/ul/li[4]/a")WebElement Logoutbutton;	
	}


