package automationexcercise;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class Placeorder_RBC_POMFB {
	@FindBy(xpath = "//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[4]/a")WebElement signuplogin;
	@FindBy(name="name")WebElement name;
	@FindBy(xpath="//*[@id=\\\"form\\\"]/div/div/div[3]/div/form/input[3]")WebElement email;
	@FindBy(xpath="//*[@id=\\\"form\\\"]/div/div/div[3]/div/form/button")WebElement signup;
	@FindBy(id="id_gender2")WebElement title;
	@FindBy(id="password")WebElement Password;
	@FindBy(id="days")WebElement dobdays;
	@FindBy(id="months")WebElement dobmonth;
	@FindBy(id="years")WebElement dobyear;
	@FindBy(id="newsletter")WebElement selectbutton;
	@FindBy(id="optin")WebElement checkbox;
	@FindBy(id="first_name")WebElement firstname;
	@FindBy(id="last_name")WebElement lastname;
	@FindBy(id="company")WebElement company;
	@FindBy(id="address1")WebElement address1;
	@FindBy(id="address2")WebElement address2;
	@FindBy(id="country")WebElement country;
	@FindBy(id="state")WebElement state;
	@FindBy(id="city")WebElement city;
	@FindBy(id="zipcode")WebElement pincode;
	@FindBy(id="mobile_number")WebElement mobile;
	@FindBy(xpath="//*[@id=\\\"form\\\"]/div/div/div/div/form/button")WebElement creataccountbutton;
	@FindBy(xpath="//*[@id=\\\"form\\\"]/div/div/div/div/a")WebElement Continuebutton;
	@FindBy(xpath = "//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[10]/a")WebElement loggedin;
    @FindBy(xpath = "/html/body/section[2]/div/div/div[2]/div[1]/div[2]/div/div[2]/ul/li/a")WebElement viewproduct;
	@FindBy(xpath = "/html/body/section/div/div/div[2]/div[2]/div[2]/div/span/button")WebElement Add2cart;
	@FindBy(xpath = "//*[@id=\"cartModal\"]/div/div/div[3]/button")WebElement continueshopping;
    @FindBy(xpath = "//*[@id=\\\"header\\\"]/div/div/div/div[2]/div/ul/li[3]/a")WebElement cartbutton;
    @FindBy(xpath = "//*[@id=\"do_action\"]/div[1]/div/div/a")WebElement checkout;
    @FindBy(xpath = "//*[@id=\\\"cart_items\\\"]/div/div[3]/div/div[1]")WebElement adressdetails;
    @FindBy(xpath = "//*[@id=\\\"cart_info\\\"]/table/tbody")WebElement orderdetails;
    @FindBy(xpath = "//*[@id=\\\"ordermsg\\\"]/textarea")WebElement description;
    @FindBy(xpath = "//*[@id=\\\"cart_items\\\"]/div/div[7]/a")WebElement placeorder;
    @FindBy(xpath = "//*[@id=\\\"payment-form\\\"]/div[1]/div/input")WebElement cardname;
    @FindBy(xpath = "//*[@id=\\\"payment-form\\\"]/div[2]/div/input")WebElement cardnumber;
    @FindBy(xpath = "//*[@id=\\\"payment-form\\\"]/div[3]/div[1]/input")WebElement cardcvv;
    @FindBy(xpath = "//*[@id=\\\"payment-form\\\"]/div[3]/div[2]/input")WebElement cardmonth;
    @FindBy(xpath = "//*[@id=\\\"payment-form\\\"]/div[3]/div[3]/input")WebElement cardyear;
    @FindBy(xpath = "//*[@id=\\\"submit\\\"]")WebElement cardpay;
    @FindBy(xpath = "//*[@id=\\\"header\\\"]/div/div/div/div[2]/div/ul/li[5]/a")WebElement DAB;
    @FindBy(xpath = "//*[@id=\\\"form\\\"]/div/div/div/h2/b")WebElement accountd;
    @FindBy(xpath = "//*[@id=\\\"form\\\"]/div/div/div/div/a")WebElement continuebutton1;	
}
