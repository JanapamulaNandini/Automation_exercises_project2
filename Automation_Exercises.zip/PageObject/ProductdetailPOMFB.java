package automationexcercise;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class ProductdetailPOMFB {

     @FindBy(xpath = "//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[2]/a")WebElement product;
     @FindBy(xpath = "/html/body/section[2]/div/div/div[2]/div/div[2]/div/div[2]/ul/li/a")WebElement firstproduct;
     @FindBy(xpath = "/html/body/section")WebElement detailpage;
}