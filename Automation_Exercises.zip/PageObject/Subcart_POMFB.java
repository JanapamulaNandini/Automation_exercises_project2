package automationexcercise;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class Subcart_POMFB {

	@FindBy(xpath = "//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[3]/a")WebElement cart;
	@FindBy(css = "#footer > div.footer-widget > div > div > div.col-sm-3.col-sm-offset-1 > div > h2")WebElement subscription;
	@FindBy(id = "susbscribe_email")WebElement email;
	@FindBy(xpath = "//*[@id=\"subscribe\"]/i")WebElement arrowbutton;	
}
