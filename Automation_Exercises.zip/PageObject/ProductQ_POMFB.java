package automationexcercise;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class ProductQ_POMFB {

    @FindBy(xpath = "/html/body/section[2]/div/div/div[2]/div[1]/div[2]/div/div[2]/ul/li/a")WebElement VPAP;
	@FindBy(xpath = "/html/body/section/div/div/div[2]")WebElement  pdo;
	@FindBy(id =  "quantity")WebElement clear;
	@FindBy(id =  "quantity")WebElement increaseQ;
	@FindBy(xpath = "/html/body/section/div/div/div[2]/div[2]/div[2]/div/span/button")WebElement add2cart;
	@FindBy(xpath = "//*[@id=\\\"cartModal\\\"]/div/div/div[2]/p[2]/a/u")WebElement V2c;
	@FindBy(xpath = "//*[@id=\\\"product-1\\\"]/td[4]/button")WebElement pcartpage;	
}
