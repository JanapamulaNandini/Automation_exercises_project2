package automationexcercise;

import java.io.File;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.Select;

public class Placeorder_LBC {

	public static void main(String[] args) throws Exception {

		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\Nandu\\Downloads\\chromedriver-win64\\chromedriver.exe");
		ChromeOptions options = new ChromeOptions();
		options.addExtensions(new File("./Extensions/AdBlock.crx"));
		DesiredCapabilities cap = new DesiredCapabilities();
		cap.setCapability(ChromeOptions.CAPABILITY, options);

		WebDriver driver = new ChromeDriver(options);
		driver.navigate().to("https://automationexercise.com/");
		driver.manage().window().maximize();
		// home page visible
		boolean homepage = driver.findElement(By.xpath("//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[1]/a"))
				.isDisplayed();
		if (homepage == true) {
			System.out.println("pass");
		} else {
			System.out.println("fail");
		}
		// SignUp / Login' button
		driver.findElement(By.xpath("//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[4]/a")).click();
		// enter email
		driver.findElement(By.name("email")).sendKeys("janapamala@00gmail.com");
		// PWD
		driver.findElement(By.name("password")).sendKeys("nandu123");
		// loginButton
		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div/div[1]/div/form/button")).click();
		// Logged in as UserName
		String LUN = driver.findElement(By.xpath("//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[10]/a")).getText();
		System.out.println(LUN);
		// 'View Product'
		driver.findElement(By.xpath("/html/body/section[2]/div/div/div[2]/div[1]/div[2]/div/div[2]/ul/li/a")).click();
		// Add product to cart
		driver.findElement(By.xpath("/html/body/section/div/div/div[2]/div[2]/div[2]/div/span/button")).click();
		// continue shopping
		driver.findElement(By.xpath("//*[@id=\"cartModal\"]/div/div/div[3]/button")).click();
		// click cart button
		driver.findElement(By.xpath("//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[3]/a")).click();
		// cart page displayed
		boolean cartpage = driver.findElement(By.xpath("//*[@id=\"cart_items\"]/div")).isDisplayed();
		if (cartpage == true) {
			System.out.println("pass");
		} else {
			System.out.println("fail");
		}
		// click proceed to checkout
		driver.findElement(By.xpath("//*[@id=\"do_action\"]/div[1]/div/div/a")).click();
		// verify address details
		boolean adressD = driver.findElement(By.xpath("//*[@id=\"cart_items\"]/div/div[3]/div/div[1]")).isDisplayed();
		if (adressD == true) {
			System.out.println("pass");
		} else {
			System.out.println("fail");
		}
		// verify order details
		boolean orderD = driver.findElement(By.xpath("//*[@id=\"cart_info\"]/table/tbody")).isDisplayed();
		if (orderD == true) {
			System.out.println("pass");
		} else {
			System.out.println("fail");
		}
		// enter description
		driver.findElement(By.xpath("//*[@id=\"ordermsg\"]/textarea")).sendKeys("Order this product fast asap");
		// click place order
		driver.findElement(By.xpath("//*[@id=\"cart_items\"]/div/div[7]/a")).click();
		// fill the card details: NAME
		driver.findElement(By.xpath("//*[@id=\"payment-form\"]/div[1]/div/input")).sendKeys("nandini");
		// card number
		driver.findElement(By.xpath("//*[@id=\"payment-form\"]/div[2]/div/input")).sendKeys("12345678901234567890");
		// cvv
		driver.findElement(By.xpath("//*[@id=\"payment-form\"]/div[3]/div[1]/input")).sendKeys("123");
		// month
		driver.findElement(By.xpath("//*[@id=\"payment-form\"]/div[3]/div[2]/input")).sendKeys("12");
		// year
		driver.findElement(By.xpath("//*[@id=\"payment-form\"]/div[3]/div[3]/input")).sendKeys("2029");
		// pay button
		driver.findElement(By.xpath("//*[@id=\"submit\"]")).click();
		// Verify success message 'Your order has been placed successfully!'
		String text = driver.findElement(By.xpath("//div[@class='alert-success alert']")).getText();
		System.out.println(text);
		// delete account button
		driver.findElement(By.xpath("//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[5]/a")).click();
		// Account deleted
		boolean AD = driver.findElement(By.xpath("//*[@id=\"form\"]/div/div/div/h2/b")).isDisplayed();
		if (AD == true) {
			System.out.println("pass");
		} else {
			System.out.println("fail");
		}
		// continue button
		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div/div/div/a")).click();
		driver.close();
	}
}
