package automationexcercise;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class SearchProduct {

	public static void main(String[] args) throws Exception {

		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\Nandu\\Downloads\\chromedriver-win64\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://automationexercise.com/");
		driver.manage().window().maximize();
		// home page visible
		boolean homepage = driver.findElement(By.xpath("//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[1]/a"))
				.isDisplayed();
		if (homepage == true) {
			System.out.println("pass");
		} else {
			System.out.println("fail");
		}
		// product
		driver.findElement(By.xpath("//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[2]/a")).click();
		// product all page
		boolean productpage = driver.findElement(By.xpath("//*[@id=\"advertisement\"]/div")).isDisplayed();
		if (productpage == true) {
			System.out.println("pass");
		} else {
			System.out.println("fail");
		}
		// enter product name
		driver.findElement(By.id("search_product")).sendKeys("winter top");
		// search button
		driver.findElement(By.id("submit_search")).click();
		// search products visible
		String searchP = driver.findElement(By.xpath("/html/body/section[2]/div/div/div[2]/div/h2")).getText();
		System.out.println(searchP);
		// all searched products
		boolean SP = driver.findElement(By.xpath("/html/body/section[2]/div/div/div[2]/div")).isDisplayed();
		if (SP == true) {
			System.out.println("pass");
		} else {
			System.out.println("fail");
		}
		driver.close();
	}
}
