package automationexcercise;

import java.io.File;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;

public class Searchproduct_verifycart_afterlogin {

	public static void main(String[] args) throws Exception {

		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\Nandu\\Downloads\\chromedriver-win64\\chromedriver.exe");
		ChromeOptions options = new ChromeOptions();
		options.addExtensions(new File("./Extensions/AdBlock.crx"));
		DesiredCapabilities cap = new DesiredCapabilities();
		cap.setCapability(ChromeOptions.CAPABILITY, options);

		WebDriver driver = new ChromeDriver(options);
		driver.navigate().to("https://automationexercise.com/");
		driver.manage().window().maximize();
		Thread.sleep(2000);
		// product
		driver.findElement(By.xpath("//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[2]/a")).click();
		// product all page
		boolean productpage = driver.findElement(By.xpath("//*[@id=\"advertisement\"]/div")).isDisplayed();
		if (productpage == true) {
			System.out.println("pass");
		} else {
			System.out.println("fail");
		}
		// enter product name
		driver.findElement(By.id("search_product")).sendKeys("winter top");
		// search button
		driver.findElement(By.id("submit_search")).click();
		// search products visible
		String searchP = driver.findElement(By.xpath("/html/body/section[2]/div/div/div[2]/div/h2")).getText();
		System.out.println(searchP);
		// all searched products
		boolean SP = driver.findElement(By.xpath("/html/body/section[2]/div/div/div[2]/div")).isDisplayed();
		if (SP == true) {
			System.out.println("pass");
		} else {
			System.out.println("fail");
		}
		// view to cart
		driver.findElement(By.xpath("/html/body/section[2]/div/div/div[2]/div/div[2]/div/div[2]/ul/li/a")).click();
		// add to cart
		driver.findElement(By.xpath("/html/body/section/div/div/div[2]/div[2]/div[2]/div/span/button")).click();
		// continue shopping
		driver.findElement(By.xpath("//*[@id=\"cartModal\"]/div/div/div[3]/button")).click();
		// click cart button
		driver.findElement(By.xpath("//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[3]/a")).click();
		// verify the products should be visible in cart page
		boolean cartpage = driver.findElement(By.xpath("//*[@id=\"cart_info\"]")).isDisplayed();
		if (cartpage == true) {
			System.out.println("pass");
		} else {
			System.out.println("fail");
		}
		// SignUp / Login' button
		driver.findElement(By.xpath("//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[4]/a")).click();
		// enter email
		driver.findElement(By.name("email")).sendKeys("nandhu@gmail.com");
		// PWD
		driver.findElement(By.name("password")).sendKeys("nandin@123");
		// loginButton
		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div/div[1]/div/form/button")).click();
		// click cart button
		driver.findElement(By.xpath("//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[3]/a")).click();
		// verify the products should be visible in cart page
		boolean cartpage1 = driver.findElement(By.xpath("//*[@id=\"cart_info\"]")).isDisplayed();
		if (cartpage1 == true) {
			System.out.println("pass");
		} else {
			System.out.println("fail");
		}
		driver.close();
	}
}
