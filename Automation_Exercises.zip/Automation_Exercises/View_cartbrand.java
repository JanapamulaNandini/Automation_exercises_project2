package automationexcercise;

import java.io.File;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;

public class View_cartbrand {

	public static void main(String[] args) throws Exception {

		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\Nandu\\Downloads\\chromedriver-win64\\chromedriver.exe");
		ChromeOptions options = new ChromeOptions();
		options.addExtensions(new File("./Extensions/AdBlock.crx"));
		DesiredCapabilities cap = new DesiredCapabilities();
		cap.setCapability(ChromeOptions.CAPABILITY, options);

		WebDriver driver = new ChromeDriver(options);
		driver.navigate().to("https://automationexercise.com/");
		driver.manage().window().maximize();
		// product
		driver.findElement(By.xpath("//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[2]/a")).click();
         //verify the brands
		driver.findElement(By.xpath("/html/body/section[2]/div/div/div[1]/div/div[2]/h2")).click();
        //click any brand name 
		driver.findElement(By.xpath("/html/body/section/div/div/div[1]/div/div[2]/div/ul/li[8]/a")).click();
		// Verify that user is navigated to brand page and brand products are displayed
       boolean brandpage = driver.findElement(By.xpath("/html/body/section/div")).isDisplayed();
	   if(brandpage==true) {
		   System.out.println("pass");
	   }
	   else {
		   System.out.println("fail");
	   }
	   //click another brand name
	   driver.findElement(By.xpath("/html/body/section/div/div[2]/div[1]/div/div[2]/div/ul/li[5]/a")).click();
	   //Verify that user is navigated to that brand page and can see products
      boolean brandpage1 = driver.findElement(By.xpath("/html/body/section/div")).isDisplayed();
      if(brandpage1==true) {
		   System.out.println("pass");
	   }
	   else {
		   System.out.println("fail");
	   }
         driver.quit();
         
	}

}
