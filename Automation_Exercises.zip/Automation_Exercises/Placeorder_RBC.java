package automationexcercise;

import java.io.File;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.Select;

public class Placeorder_RBC {

	public static void main(String[] args) throws Exception {

		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\Nandu\\Downloads\\chromedriver-win64\\chromedriver.exe");
		ChromeOptions options = new ChromeOptions();
		options.addExtensions(new File("./Extensions/AdBlock.crx"));
		DesiredCapabilities cap = new DesiredCapabilities();
		cap.setCapability(ChromeOptions.CAPABILITY, options);

		WebDriver driver = new ChromeDriver(options);
		driver.navigate().to("https://automationexercise.com/");
		driver.manage().window().maximize();
		// home page visible
		boolean homepage = driver.findElement(By.xpath("//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[1]/a"))
				.isDisplayed();
		if (homepage == true) {
			System.out.println("pass");
		} else {
			System.out.println("fail");
		}
		// SignUp / Login' button
		driver.findElement(By.xpath("//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[4]/a")).click();
		// Enter name
		driver.findElement(By.name("name")).sendKeys("nandu");
		// email
		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div/div[3]/div/form/input[3]"))
				.sendKeys("nandhu138@gmail.com");
		// signUp button
		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div/div[3]/div/form/button")).click();
		// Title
		driver.findElement(By.id("id_gender2")).click();
		// password
		driver.findElement(By.id("password")).sendKeys("nandin@123");
		Thread.sleep(2000);
		// DOB - days
		WebElement daydropdown = driver.findElement(By.id("days"));
		Select obj1 = new Select(daydropdown);
		obj1.selectByValue("6");
		// month
		WebElement monthdd = driver.findElement(By.id("months"));
		Select obj2 = new Select(monthdd);
		obj2.selectByIndex(9);
		// year
		WebElement yeardd = driver.findElement(By.id("years"));
		Select obj3 = new Select(yeardd);
		obj3.selectByVisibleText("1997");
		// checkBoxnewsletter
		driver.findElement(By.id("newsletter")).click();
		// checkBox
		driver.findElement(By.id("optin")).click();
		// First name
		driver.findElement(By.id("first_name")).sendKeys("janapamala");
		// Last name
		driver.findElement(By.id("last_name")).sendKeys("j");
		// Company
		driver.findElement(By.id("company")).sendKeys("Amazon");
		// Address1
		driver.findElement(By.id("address1")).sendKeys("plotno-109");
		// Address2
		driver.findElement(By.id("address2")).sendKeys("plotno-108");
		// Country
		driver.findElement(By.id("country")).sendKeys("india");
		// State
		driver.findElement(By.id("state")).sendKeys("Telangana");
		// City
		driver.findElement(By.id("city")).sendKeys("Hyderabad");
		// ZipCode
		driver.findElement(By.id("zipcode")).sendKeys("500000");
		// Mobile Number
		driver.findElement(By.id("mobile_number")).sendKeys("1234567890");
		// Create Account button
		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div/div/div/form/button")).click();
		// ACCOUNT CREATED
		String AC = driver.findElement(By.xpath("//*[@id=\"form\"]/div/div/div/h2/b")).getText();
		System.out.println(AC);
		// Continue
		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div/div/div/a")).click();
		// Logged in as UserName
		String LUN = driver.findElement(By.xpath("//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[10]/a")).getText();
		System.out.println(LUN);
		// 'View Product'
		driver.findElement(By.xpath("/html/body/section[2]/div/div/div[2]/div[1]/div[2]/div/div[2]/ul/li/a")).click();
		// Add product to cart
		driver.findElement(By.xpath("/html/body/section/div/div/div[2]/div[2]/div[2]/div/span/button")).click();
		// continue shopping
		driver.findElement(By.xpath("//*[@id=\"cartModal\"]/div/div/div[3]/button")).click();
		// click cart button
		driver.findElement(By.xpath("//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[3]/a")).click();
		// cart page displayed
		boolean cartpage = driver.findElement(By.xpath("//*[@id=\"cart_items\"]/div")).isDisplayed();
		if (cartpage == true) {
			System.out.println("pass");
		} else {
			System.out.println("fail");
		}
		Thread.sleep(2000);
		// click proceed to checkout
		driver.findElement(By.xpath("//*[@id=\"do_action\"]/div[1]/div/div/a")).click();
		// verify address details
		boolean adressD = driver.findElement(By.xpath("//*[@id=\"cart_items\"]/div/div[3]/div/div[1]")).isDisplayed();
		if (adressD == true) {
			System.out.println("pass");
		} else {
			System.out.println("fail");
		}
		// verify order details
		boolean orderD = driver.findElement(By.xpath("//*[@id=\"cart_info\"]/table/tbody")).isDisplayed();
		if (orderD == true) {
			System.out.println("pass");
		} else {
			System.out.println("fail");
		}
		// enter description
		driver.findElement(By.xpath("//*[@id=\"ordermsg\"]/textarea")).sendKeys("Order this product fast asap");
		// click place order
		driver.findElement(By.xpath("//*[@id=\"cart_items\"]/div/div[7]/a")).click();
		// fill the card details: NAME
		driver.findElement(By.xpath("//*[@id=\"payment-form\"]/div[1]/div/input")).sendKeys("nandini");
		// card number
		driver.findElement(By.xpath("//*[@id=\"payment-form\"]/div[2]/div/input")).sendKeys("12345678901234567890");
		// cvv
		driver.findElement(By.xpath("//*[@id=\"payment-form\"]/div[3]/div[1]/input")).sendKeys("123");
		// month
		driver.findElement(By.xpath("//*[@id=\"payment-form\"]/div[3]/div[2]/input")).sendKeys("12");
		// year
		driver.findElement(By.xpath("//*[@id=\"payment-form\"]/div[3]/div[3]/input")).sendKeys("2029");
		// pay button
		driver.findElement(By.xpath("//*[@id=\"submit\"]")).click();
		// Verify success message 'Your order has been placed successfully!'
		String text = driver.findElement(By.xpath("//div[@class='alert-success alert']")).getText();
		System.out.println(text);
		// delete account button
		driver.findElement(By.xpath("//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[5]/a")).click();
		// Account deleted
		boolean AD = driver.findElement(By.xpath("//*[@id=\"form\"]/div/div/div/h2/b")).isDisplayed();
		if (AD == true) {
			System.out.println("pass");
		} else {
			System.out.println("fail");
		}
		// continue button
		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div/div/div/a")).click();
		driver.close();
	}
}
