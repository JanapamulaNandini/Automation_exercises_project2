package automationexcercise;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class ProductQuantity {

	public static void main(String[] args) throws Exception {

		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\Nandu\\Downloads\\chromedriver-win64\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.navigate().to("https://automationexercise.com/");
		driver.manage().window().maximize();
		// home page visible
		boolean homepage = driver.findElement(By.xpath("//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[1]/a"))
				.isDisplayed();
		if (homepage == true) {
			System.out.println("pass");
		} else {
			System.out.println("fail");
		}
		// 'View Product' for any product on home page
		driver.findElement(By.xpath("/html/body/section[2]/div/div/div[2]/div[1]/div[2]/div/div[2]/ul/li/a")).click();
		// product detail is opened
		boolean pd = driver.findElement(By.xpath("/html/body/section/div/div/div[2]")).isDisplayed();
		if (pd == true) {
			System.out.println("pass");
		} else {
			System.out.println("fail");
		}
		// Increase quantity to 4
		WebElement quantityDD = driver.findElement(By.id("quantity"));
		quantityDD.clear();
		quantityDD.sendKeys("4");
		// Click 'Add to cart' button
		driver.findElement(By.xpath("/html/body/section/div/div/div[2]/div[2]/div[2]/div/span/button")).click();
		// Click 'View Cart' button
		driver.findElement(By.xpath("//*[@id=\"cartModal\"]/div/div/div[2]/p[2]/a/u")).click();
		// Verify that product is displayed in cart page with exact quantity
		boolean PQ = driver.findElement(By.xpath("//*[@id=\"product-1\"]/td[4]/button")).isDisplayed();
		if (PQ == true) {
			System.out.println("pass");
		} else {
			System.out.println("fail");
		}
		driver.close();
	}
}
