package automationexcercise;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class LogoutUser {

	public static void main(String[] args) throws Exception {

		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\Nandu\\Downloads\\chromedriver-win64\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://automationexercise.com/");
		driver.manage().window().maximize();
		// home page visible
		boolean homepage = driver.findElement(By.xpath("//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[1]/a"))
				.isDisplayed();
		if (homepage == true) {
			System.out.println("pass");
		} else {
			System.out.println("fail");
		}
		// SignUp / Login' button
		driver.findElement(By.xpath("//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[4]/a")).click();
		// Login account visible
		String loginact = driver.findElement(By.xpath("//*[@id=\"form\"]/div/div/div[1]/div/h2")).getText();
		System.out.println(loginact);
		// enter email
		driver.findElement(By.name("email")).sendKeys("nandin12@gmail.com");
		// PWD
		driver.findElement(By.name("password")).sendKeys("NANDU10");
		// loginButton
		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div/div[1]/div/form/button")).click();
		// Logged in as UserName
		String LUN = driver.findElement(By.xpath("//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[10]/a")).getText();
		System.out.println(LUN);
		// logoutButton
		driver.findElement(By.xpath("//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[4]/a")).click();
		// navigated to login page
		boolean Returnloginpage = driver.findElement(By.xpath("/html/body")).isDisplayed();
		if (Returnloginpage == true) {
			System.out.println("pass");
		} else {
			System.out.println("fail");
		}
		driver.quit();
	}
}
