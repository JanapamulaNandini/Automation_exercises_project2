package automationexcercise;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class ContactUS {

	public static void main(String[] args) throws Exception {

		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\Nandu\\Downloads\\chromedriver-win64\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://automationexercise.com/");
		driver.manage().window().maximize();
		// home page visible
		boolean homepage = driver.findElement(By.xpath("//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[1]/a"))
				.isDisplayed();
		if (homepage == true) {
			System.out.println("pass");
		} else {
			System.out.println("fail");
		}
		// Click on 'Contact Us' button
		driver.findElement(By.xpath("//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[8]/a")).click();
		//
		String getIT = driver.findElement(By.xpath("//*[@id=\"contact-page\"]/div[2]/div[1]/div/h2")).getText();
		System.out.println(getIT);
		// Enter name
		driver.findElement(By.name("name")).sendKeys("nandini");
		// email
		driver.findElement(By.name("email")).sendKeys("nandini8@gmail.com");
		// subject
		driver.findElement(By.name("subject")).sendKeys("product");
		// message
		driver.findElement(By.name("message")).sendKeys("products are not visible");
		// click upload file
		driver.findElement(By.name("upload_file")).sendKeys("C:\\Users\\Nandu\\Downloads\\testing image.png");
		// click submit button
		driver.findElement(By.name("submit")).click();
		// 9. Click OK button
		Alert a = driver.switchTo().alert();
		a.accept();
		// Verify success message 'Success! Your details have been submitted
		// successfully.' is visible
		String text = driver.findElement(By.xpath("//*[@id=\"contact-page\"]/div[2]/div[1]/div/div[2]")).getText();
		System.out.println(text);
		// 11. Click 'Home' button and verify that landed to home page successfully
		driver.findElement(By.xpath("//*[@id=\"form-section\"]/a/span")).click();
		boolean HomeP = driver.findElement(By.xpath("/html/body")).isDisplayed();
		if (HomeP == true) {
			System.out.println("pass");
		} else {
			System.out.println("fail");
		}
		driver.close();
	}
}
