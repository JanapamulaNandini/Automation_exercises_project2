package automationexcercise;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class ReviewaddProduct {

	public static void main(String[] args) throws Exception {

		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\Nandu\\Downloads\\chromedriver-win64\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://automationexercise.com/");
		driver.manage().window().maximize();
		// product
		driver.findElement(By.xpath("//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[2]/a")).click();
		// product all page
		boolean productpage = driver.findElement(By.xpath("//*[@id=\"advertisement\"]/div")).isDisplayed();
		if (productpage == true) {
			System.out.println("pass");
		} else {
			System.out.println("fail");
		}
		// Click on 'View Product' button
		driver.findElement(By.xpath("/html/body/section[2]/div/div/div[2]/div/div[2]/div/div[2]/ul/li/a")).click();
		// verify the write your review
		boolean review = driver.findElement(By.xpath("/html/body/section/div/div/div[2]/div[3]/div[1]/ul/li/a"))
				.isDisplayed();
		if (review == true) {
			System.out.println("pass");
		} else {
			System.out.println("fail");
		}
		// Enter name
		driver.findElement(By.id("name")).sendKeys("nandini");
		// email
		driver.findElement(By.id("email")).sendKeys("nandhini@gmail.com");
		// review
		driver.findElement(By.xpath("//*[@id=\"review\"]")).sendKeys("product quality is good");
		// submit button
		driver.findElement(By.id("button-review")).click();
		// Verify success message 'Thank you for your review.'
		String text = driver.findElement(By.xpath("//*[@id=\"review-section\"]/div/div/span")).getText();
		System.out.println(text);
		driver.close();
	}
}
