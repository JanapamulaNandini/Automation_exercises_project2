package automationexcercise;

import java.io.File;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;

public class Viewcatproduct {

	public static void main(String[] args) throws Exception {

		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\Nandu\\Downloads\\chromedriver-win64\\chromedriver.exe");
		ChromeOptions options = new ChromeOptions();
		options.addExtensions(new File("./Extensions/AdBlock.crx"));
		DesiredCapabilities cap = new DesiredCapabilities();
		cap.setCapability(ChromeOptions.CAPABILITY, options);

		WebDriver driver = new ChromeDriver(options);
		driver.navigate().to("https://automationexercise.com/");
		driver.manage().window().maximize();
		// verify the category
		boolean category = driver.findElement(By.xpath("/html/body/section[2]/div/div/div[1]/div/h2")).isDisplayed();
		if (category == true) {
			System.out.println("pass");
		} else {
			System.out.println("fail");
		}
		// click on women category
		driver.findElement(By.xpath("//*[@id=\"accordian\"]/div[1]/div[1]/h4/a")).click();
		// click any category in women category
		driver.findElement(By.xpath("//*[@id=\"Women\"]/div/ul/li[2]/a")).click();
		// Verify that category page is displayed and confirm text 'WOMEN - TOPS
		// PRODUCTS'
		String text = driver.findElement(By.xpath("/html/body/section/div/div[2]/div[2]/div/h2")).getText();
		System.out.println(text);
		// click on men category
		driver.findElement(By.xpath("//*[@id=\"accordian\"]/div[2]/div[1]/h4/a")).click();
		// click any category in men category
		driver.findElement(By.xpath("//*[@id=\"Men\"]/div/ul/li[2]/a")).click();
		// Verify that user is navigated to that category page
		boolean categorypage = driver.findElement(By.xpath("/html/body/section/div")).isDisplayed();
		if (categorypage == true) {
			System.out.println("pass");
		} else {
			System.out.println("fail");
		}
		driver.close();
	}
}
