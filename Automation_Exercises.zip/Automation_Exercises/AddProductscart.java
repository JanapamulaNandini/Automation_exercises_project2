package automationexcercise;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class AddProductscart {

	public static void main(String[] args) throws Exception {

		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\Nandu\\Downloads\\chromedriver-win64\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.navigate().to("https://automationexercise.com/");
		driver.manage().window().maximize();
		// home page visible
		boolean homepage = driver.findElement(By.xpath("//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[1]/a"))
				.isDisplayed();
		if (homepage == true) {
			System.out.println("pass");
		} else {
			System.out.println("fail");
		}
		// product
		driver.findElement(By.xpath("//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[2]/a")).click();
		// mouse over first product
		WebElement firstp = driver
				.findElement(By.xpath("/html/body/section[2]/div/div/div[2]/div/div[2]/div/div[1]/div[2]"));
		Actions action = new Actions(driver);
		action.moveToElement(firstp).perform();
		// add to cart
		driver.findElement(By.xpath("/html/body/section[2]/div/div/div[2]/div/div[2]/div/div[1]/div[2]/div/a")).click();
		// continue shopping
		driver.findElement(By.xpath("//*[@id=\"cartModal\"]/div/div/div[3]/button")).click();
		// mouse over second product
		WebElement secondp = driver
				.findElement(By.xpath("/html/body/section[2]/div/div/div[2]/div/div[3]/div/div[1]/div[2]"));
		Actions action1 = new Actions(driver);
		action1.moveToElement(secondp).perform();
		// Add to cart2
		driver.findElement(By.xpath("/html/body/section[2]/div/div/div[2]/div/div[3]/div/div[1]/div[2]/div/a")).click();
		// click view cart
		driver.findElement(By.xpath("//*[@id=\"cartModal\"]/div/div/div[2]/p[2]/a/u")).click();
		// verify products added in cart are visible
		boolean cartproducts = driver.findElement(By.xpath("//*[@id=\"cart_info\"]")).isDisplayed();
		if (cartproducts == true) {
			System.out.println("pass");
		} else {
			System.out.println("fail");
		}
		// first product price
		boolean FPP = driver.findElement(By.xpath("//*[@id=\"product-1\"]/td[3]/p")).isDisplayed();
		if (FPP == true) {
			System.out.println("pass");
		} else {
			System.out.println("fail");
		}
		// Second product price
		boolean SPP = driver.findElement(By.xpath("//*[@id=\"product-2\"]/td[5]/p")).isDisplayed();
		if (SPP == true) {
			System.out.println("pass");
		} else {
			System.out.println("fail");
		}
		// first product quantity
		boolean FPQ = driver.findElement(By.xpath("//*[@id=\"product-1\"]/td[4]/button")).isDisplayed();
		if (FPQ == true) {
			System.out.println("pass");
		} else {
			System.out.println("fail");
		}
		// Second product quantity
		boolean SPQ = driver.findElement(By.xpath("//*[@id=\"product-2\"]/td[4]/button")).isDisplayed();
		if (SPQ == true) {
			System.out.println("pass");
		} else {
			System.out.println("fail");
		}
		// first product total price
		boolean FPTP = driver.findElement(By.xpath("//*[@id=\"product-1\"]/td[5]/p")).isDisplayed();
		if (FPTP == true) {
			System.out.println("pass");
		} else {
			System.out.println("fail");
		}
		// Second product total price
		boolean SPTP = driver.findElement(By.xpath("//*[@id=\"product-2\"]/td[5]/p")).isDisplayed();
		if (SPTP == true) {
			System.out.println("pass");
		} else {
			System.out.println("fail");
		}
		driver.close();
	}
}
