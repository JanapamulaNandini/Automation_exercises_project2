package automationexcercise;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class SubHomepage {

	public static void main(String[] args) throws Exception {

		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\Nandu\\Downloads\\chromedriver-win64\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://automationexercise.com/");
		driver.manage().window().maximize();
		// home page visible
		boolean homepage = driver.findElement(By.xpath("//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[1]/a"))
				.isDisplayed();
		if (homepage == true) {
			System.out.println("pass");
		} else {
			System.out.println("fail");
		}
		// scroll down
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,9000)");
		// SUBSCRIPTION
				String subscription = driver.findElement(
						By.cssSelector("#footer > div.footer-widget > div > div > div.col-sm-3.col-sm-offset-1 > div > h2"))
						.getText();
				System.out.println(subscription);
				// enter mail
				driver.findElement(By.id("susbscribe_email")).sendKeys("nandini0@gmail.com");
				Thread.sleep(2000);
				// arrow button
				driver.findElement(By.xpath("//*[@id=\"subscribe\"]/i")).click();
				// verify successful message
				String text = driver.findElement(By.xpath("//*[@id=\"success-subscribe\"]/div")).getText();
				System.out.println(text);
		driver.close();
	}
}
