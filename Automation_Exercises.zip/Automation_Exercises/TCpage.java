package automationexcercise;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class TCpage {

	public static void main(String[] args) throws Exception {

		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\Nandu\\Downloads\\chromedriver-win64\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://automationexercise.com/");
		driver.manage().window().maximize();
		// home page visible
		boolean homepage = driver.findElement(By.xpath("//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[1]/a"))
				.isDisplayed();
		if (homepage == true) {
			System.out.println("pass");
		} else {
			System.out.println("fail");
		}
		// click test case button
		driver.findElement(By.xpath("//*[@id=\"slider-carousel\"]/div/div[1]/div[1]/a[1]/button")).click();
		// Verify user is navigated to test cases page successfully
		boolean TCpage = driver.findElement(By.xpath("/html/body")).isDisplayed();
		if (TCpage == true) {
			System.out.println("pass");
		} else {
			System.out.println("fail");
		}
		driver.close();

	}

}
		

	
