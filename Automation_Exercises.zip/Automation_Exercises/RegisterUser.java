package automationexcercise;

import java.io.File;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.Select;

import javaprogram.stringFunction;

public class RegisterUser {

	public static void main(String[] args) throws Exception {

		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\Nandu\\Downloads\\chromedriver-win64//chromedriver.exe");
		ChromeOptions options = new ChromeOptions();
		options.addExtensions(new File("./Extensions/AdBlock.crx"));
		DesiredCapabilities cap = new DesiredCapabilities();
		cap.setCapability(ChromeOptions.CAPABILITY, options);

		WebDriver driver = new ChromeDriver(options);
		driver.navigate().to("https://automationexercise.com/");
		driver.manage().window().maximize();
		// home page visible
		boolean homepage = driver.findElement(By.xpath("//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[1]/a"))
				.isDisplayed();
		if (homepage == true) {
			System.out.println("pass");
		} else {
			System.out.println("fail");
		}
		// SignUp / Login' button
		driver.findElement(By.xpath("//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[4]/a")).click();
		// New User SignUp
		String loginavailability = driver.findElement(By.xpath("//*[@id=\"form\"]/div/div/div[3]/div/h2")).getText();
		System.out.println(loginavailability);
		// Enter name
		driver.findElement(By.name("name")).sendKeys("nandu");
		// email
		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div/div[3]/div/form/input[3]")).sendKeys("nandhu@gmail.com");
		// signUp button
		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div/div[3]/div/form/button")).click();
		// ENTERACCOUNTINFORMATION
		String EAI = driver.findElement(By.xpath("//*[@id=\"form\"]/div/div/div/div/h2/b")).getText();
		System.out.println(EAI);
		// Title
		driver.findElement(By.id("id_gender2")).click();
		// password
		driver.findElement(By.id("password")).sendKeys("nandin@123");
		// DOB - days
		WebElement daydropdown = driver.findElement(By.id("days"));
		Select obj1 = new Select(daydropdown);
		obj1.selectByValue("6");
		// month
		WebElement monthdd = driver.findElement(By.id("months"));
		Select obj2 = new Select(monthdd);
		obj2.selectByIndex(9);
		// year
		WebElement yeardd = driver.findElement(By.id("years"));
		Select obj3 = new Select(yeardd);
		obj3.selectByVisibleText("1997");
		// checkBoxnewsletter
		driver.findElement(By.id("newsletter")).click();
		// checkBox
		driver.findElement(By.id("optin")).click();
		// First name
		driver.findElement(By.id("first_name")).sendKeys("nandini");
		// Last name
		driver.findElement(By.id("last_name")).sendKeys("j");
		// Company
		driver.findElement(By.id("company")).sendKeys("Amazon");
		// Address1
		driver.findElement(By.id("address1")).sendKeys("plotno-109");
		// Address2
		driver.findElement(By.id("address2")).sendKeys("plotno-108");
		// Country
		driver.findElement(By.id("country")).sendKeys("india");
		// State
		driver.findElement(By.id("state")).sendKeys("Telangana");
		// City
		driver.findElement(By.id("city")).sendKeys("Hyderabad");
		// ZipCode
		driver.findElement(By.id("zipcode")).sendKeys("500000");
		// Mobile Number
		driver.findElement(By.id("mobile_number")).sendKeys("1234567890");
		// Create Account button
		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div/div/div/form/button")).click();
		// ACCOUNT CREATED
		String AC = driver.findElement(By.xpath("//*[@id=\"form\"]/div/div/div/h2/b")).getText();
		System.out.println(AC);
		// Continue
		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div/div/div/a")).click();
		// Logged in as UserName
		String LUN = driver.findElement(By.xpath("//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[10]/a")).getText();
		System.out.println(LUN);
		// Delete Account button
		driver.findElement(By.xpath("//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[5]/a")).click();
		// ACCOUNT DELETED
		String ad = driver.findElement(By.xpath("//*[@id=\"form\"]/div/div/div/h2/b")).getText();
		System.out.println(ad);
		// ContinueButton
		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div/div/div/a")).click();
		}
    
}
