package testNGframework;

import java.io.File;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class ProductDetails {
	WebDriver driver;

	@BeforeTest
	public void launchapp() throws Exception {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\Nandu\\Downloads\\chromedriver-win64//chromedriver.exe");
		driver = new ChromeDriver();
		driver.navigate().to("https://automationexercise.com/");
		driver.manage().window().maximize();
	}

	@Test
	public void productdetail() {
		boolean homepage = driver.findElement(By.xpath("//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[1]/a"))
				.isDisplayed();
		if (homepage == true) {
			System.out.println("pass");
		} else {
			System.out.println("fail");
		}
		driver.findElement(By.xpath("//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[2]/a")).click();
		boolean productpage = driver.findElement(By.xpath("//h2[@class='title text-center']")).isDisplayed();
		if (productpage == true) {
			System.out.println("pass");
		} else {
			System.out.println("fail");
		}
		boolean productlist = driver.findElement(By.xpath("/html/body/section[2]/div/div/div[2]/div")).isDisplayed();
		if (productlist == true) {
			System.out.println("pass");
		} else {
			System.out.println("fail");
		}
		driver.findElement(By.xpath("/html/body/section[2]/div/div/div[2]/div/h2")).click();
		boolean productDP = driver.findElement(By.xpath("/html/body/section")).isDisplayed();
		if (productDP == true) {
			System.out.println("pass");
		} else {
			System.out.println("fail");
		}
		boolean product = driver.findElement(By.xpath("/html/body/section/div/div/div[2]/div[2]/div[2]/div/h2"))
				.isDisplayed();
		if (product == true) {
			System.out.println("pass");
		} else {
			System.out.println("fail");
		}
		boolean category = driver.findElement(By.xpath("/html/body/section/div/div/div[2]/div[2]/div[2]/div/p[1]"))
				.isDisplayed();
		if (category == true) {
			System.out.println("pass");
		} else {
			System.out.println("fail");
		}
		boolean p = driver.findElement(By.xpath("/html/body/section/div/div/div[2]/div[2]/div[2]/div/span/span"))
				.isDisplayed();
		if (p == true) {
			System.out.println("pass");
		} else {
			System.out.println("fail");
		}
		boolean a = driver.findElement(By.xpath("/html/body/section/div/div/div[2]/div[2]/div[2]/div/p[2]/b"))
				.isDisplayed();
		if (a = true) {
			System.out.println("pass");
		} else {
			System.out.println("fail");
		}
		boolean condition = driver.findElement(By.xpath("/html/body/section/div/div/div[2]/div[2]/div[2]/div/p[3]/b"))
				.isDisplayed();
		if (condition == true) {
			System.out.println("pass");
		} else {
			System.out.println("fail");
		}
		boolean brand = driver.findElement(By.xpath("/html/body/section/div/div/div[2]/div[2]/div[2]/div/p[4]/b"))
				.isDisplayed();
		if (brand == true) {
			System.out.println("pass");
		} else {
			System.out.println("fail");
		}
	}

	@AfterTest
	public void closeapp() {
		driver.close();
	}
}
