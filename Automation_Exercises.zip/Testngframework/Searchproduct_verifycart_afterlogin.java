package testNGframework;

import java.io.File;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class Searchproduct_verifycart_afterlogin {
	WebDriver driver;

	@BeforeTest
	public void launchapp() throws Exception {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\Nandu\\Downloads\\chromedriver-win64//chromedriver.exe");
		driver = new ChromeDriver();
		driver.navigate().to("https://automationexercise.com/");
		driver.manage().window().maximize();
	}

	@Test
	public void AddP2C() {
		boolean productpage = driver.findElement(By.xpath("//*[@id=\"advertisement\"]/div")).isDisplayed();
		if (productpage == true) {
			System.out.println("pass");
		} else {
			System.out.println("fail");
		}
		driver.findElement(By.id("search_product")).sendKeys("winter top");
		driver.findElement(By.id("submit_search")).click();
		String searchP = driver.findElement(By.xpath("/html/body/section[2]/div/div/div[2]/div/h2")).getText();
		System.out.println(searchP);
		boolean SP = driver.findElement(By.xpath("/html/body/section[2]/div/div/div[2]/div")).isDisplayed();
		if (SP == true) {
			System.out.println("pass");
		} else {
			System.out.println("fail");
		}
		driver.findElement(By.xpath("/html/body/section[2]/div/div/div[2]/div/div[2]/div/div[2]/ul/li/a")).click();
		driver.findElement(By.xpath("/html/body/section/div/div/div[2]/div[2]/div[2]/div/span/button")).click();
		driver.findElement(By.xpath("//*[@id=\"cartModal\"]/div/div/div[3]/button")).click();
		driver.findElement(By.xpath("//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[3]/a")).click(); // verify the
																										// products
																										// should be
																										// visible in
																										// cart page
		boolean cartpage = driver.findElement(By.xpath("//*[@id=\"cart_info\"]")).isDisplayed();
		if (cartpage == true) {
			System.out.println("pass");
		} else {
			System.out.println("fail");
		}
		driver.findElement(By.xpath("//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[4]/a")).click();
		driver.findElement(By.name("email")).sendKeys("nandhu@gmail.com");
		driver.findElement(By.name("password")).sendKeys("nandin@123");
		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div/div[1]/div/form/button")).click();
		driver.findElement(By.xpath("//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[3]/a")).click();
		boolean cartpage1 = driver.findElement(By.xpath("//*[@id=\"cart_info\"]")).isDisplayed();
		if (cartpage1 == true) {
			System.out.println("pass");
		} else {
			System.out.println("fail");
		}
	}

	@AfterTest
	public void closeapp() {
		driver.close();
	}
}
