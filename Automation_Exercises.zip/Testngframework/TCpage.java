package testNGframework;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class TCpage {
	WebDriver driver;

	@BeforeTest
	public void launchapp() throws Exception {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\Nandu\\Downloads\\chromedriver-win64//chromedriver.exe");
		driver = new ChromeDriver();
		driver.navigate().to("https://automationexercise.com/");
		driver.manage().window().maximize();
	}

	@Test
	public void Testcasepage() {
		boolean homepage = driver.findElement(By.xpath("//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[1]/a"))
				.isDisplayed();
		if (homepage == true) {
			System.out.println("pass");
		} else {
			System.out.println("fail");
		}
		driver.findElement(By.xpath("//*[@id=\"slider-carousel\"]/div/div[1]/div[1]/a[1]/button")).click();
		boolean TCpage = driver.findElement(By.xpath("/html/body")).isDisplayed();
		if (TCpage == true) {
			System.out.println("pass");
		} else {
			System.out.println("fail");
		}
	}

	@AfterTest
	public void closeapp() {
		driver.close();
	}

}
