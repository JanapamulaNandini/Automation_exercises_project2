package testNGframework;

import java.io.File;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class RegisterUser {
	WebDriver driver;

	@BeforeTest
	public void launchapp() throws Exception {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\Nandu\\Downloads\\chromedriver-win64//chromedriver.exe");
		driver = new ChromeDriver();
		driver.navigate().to("https://automationexercise.com/");
		driver.manage().window().maximize();
		Thread.sleep(1000);
	}

	@Test
	public void t1() throws Exception {
		boolean homepage = driver.findElement(By.xpath("//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[1]/a"))
				.isDisplayed();
		if (homepage == true) {
			System.out.println("pass");
		} else {
			System.out.println("fail");
		}

		driver.findElement(By.xpath("//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[4]/a")).click();
		String loginavailability = driver.findElement(By.xpath("//*[@id=\"form\"]/div/div/div[3]/div/h2")).getText();
		System.out.println(loginavailability);
		driver.findElement(By.name("name")).sendKeys("nandu");
		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div/div[3]/div/form/input[3]"))
				.sendKeys("nnnandhii12090@gmail.com");
		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div/div[3]/div/form/button")).click();
		String EAI = driver.findElement(By.xpath("//*[@id=\"form\"]/div/div/div/div/h2/b")).getText();
		System.out.println(EAI);
		driver.findElement(By.id("id_gender2")).click();
		driver.findElement(By.id("password")).sendKeys("nandin@123");
		WebElement daydropdown = driver.findElement(By.id("days"));
		Select obj1 = new Select(daydropdown);
		obj1.selectByValue("6");
		WebElement monthdd = driver.findElement(By.id("months"));
		Select obj2 = new Select(monthdd);
		obj2.selectByIndex(9);
		WebElement yeardd = driver.findElement(By.id("years"));
		Select obj3 = new Select(yeardd);
		obj3.selectByVisibleText("1997");
		driver.findElement(By.id("newsletter")).click();
		driver.findElement(By.id("optin")).click();
		driver.findElement(By.id("first_name")).sendKeys("nandini");
		driver.findElement(By.id("last_name")).sendKeys("j");
		driver.findElement(By.id("company")).sendKeys("Amazon");
		driver.findElement(By.id("address1")).sendKeys("plotno-109");
		driver.findElement(By.id("address2")).sendKeys("plotno-108");
		driver.findElement(By.id("country")).sendKeys("india");
		driver.findElement(By.id("state")).sendKeys("Telangana");
		driver.findElement(By.id("city")).sendKeys("Hyderabad");
		driver.findElement(By.id("zipcode")).sendKeys("500000");
		driver.findElement(By.id("mobile_number")).sendKeys("1234567890");
		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div/div/div/form/button")).click();
		String AC = driver.findElement(By.xpath("//*[@id=\"form\"]/div/div/div/h2/b")).getText();
		System.out.println(AC);
		driver.findElement(By.xpath("//a[text()='Continue']")).click();
		String LUN = driver.findElement(By.xpath("//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[10]/a")).getText();
		System.out.println(LUN);
		driver.findElement(By.xpath("//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[5]/a")).click();
		String ad = driver.findElement(By.xpath("//*[@id=\"form\"]/div/div/div/h2/b")).getText();
		System.out.println(ad);
		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div/div/div/a")).click();
	}

	@AfterTest
	public void closeapp() {
		driver.close();
	}
}
