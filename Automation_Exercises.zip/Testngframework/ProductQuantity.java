package testNGframework;

import java.io.File;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class ProductQuantity {
	WebDriver driver;

	@BeforeTest
	public void launchapp() throws Exception {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\Nandu\\Downloads\\chromedriver-win64//chromedriver.exe");
		driver = new ChromeDriver();
		driver.navigate().to("https://automationexercise.com/");
		driver.manage().window().maximize();
	}

	@Test
	public void ProductQ() {
		boolean homepage = driver.findElement(By.xpath("//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[1]/a"))
				.isDisplayed();
		if (homepage == true) {
			System.out.println("pass");
		} else {
			System.out.println("fail");
		}
		driver.findElement(By.xpath("/html/body/section[2]/div/div/div[2]/div[1]/div[2]/div/div[2]/ul/li/a")).click();
		boolean pd = driver.findElement(By.xpath("/html/body/section/div/div/div[2]")).isDisplayed();
		if (pd == true) {
			System.out.println("pass");
		} else {
			System.out.println("fail");
		}
		WebElement quantityDD = driver.findElement(By.id("quantity"));
		quantityDD.clear();
		quantityDD.sendKeys("4");
		driver.findElement(By.xpath("/html/body/section/div/div/div[2]/div[2]/div[2]/div/span/button")).click();
		driver.findElement(By.xpath("//*[@id=\"cartModal\"]/div/div/div[2]/p[2]/a/u")).click();
		boolean PQ = driver.findElement(By.xpath("//*[@id=\"product-1\"]/td[4]/button")).isDisplayed();
		if (PQ == true) {
			System.out.println("pass");
		} else {
			System.out.println("fail");
		}
	}

	@AfterTest
	public void closeapp() {
		driver.close();
	}
}
