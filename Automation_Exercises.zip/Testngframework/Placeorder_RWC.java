package testNGframework;

import java.io.File;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class Placeorder_RWC {
	WebDriver driver;

	@BeforeTest
	public void launchapp() throws Exception {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\Nandu\\Downloads\\chromedriver-win64//chromedriver.exe");
		driver = new ChromeDriver();
		driver.navigate().to("https://automationexercise.com/");
		driver.manage().window().maximize();
	}

	@Test
	public void PlaceORWC() throws Exception {
		boolean homepage = driver.findElement(By.xpath("//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[1]/a"))
				.isDisplayed();
		if (homepage == true) {
			System.out.println("pass");
		} else {
			System.out.println("fail");
		}
		driver.findElement(By.xpath("/html/body/section[2]/div/div/div[2]/div[1]/div[2]/div/div[2]/ul/li/a")).click();
		driver.findElement(By.xpath("/html/body/section/div/div/div[2]/div[2]/div[2]/div/span/button")).click();
		driver.findElement(By.xpath("//*[@id=\"cartModal\"]/div/div/div[3]/button")).click();
		driver.findElement(By.xpath("//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[3]/a")).click();
		boolean cartpage = driver.findElement(By.xpath("//*[@id=\"cart_items\"]/div")).isDisplayed();
		if (cartpage == true) {
			System.out.println("pass");
		} else {
			System.out.println("fail");
		}
		driver.findElement(By.xpath("//*[@id=\"do_action\"]/div[1]/div/div/a")).click();
		driver.findElement(By.xpath("//*[@id=\"checkoutModal\"]/div/div/div[2]/p[2]/a/u")).click();
		driver.findElement(By.name("name")).sendKeys("nandinij");
		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div/div[3]/div/form/input[3]"))
				.sendKeys("janapalaj12304@gmail.com");
		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div/div[3]/div/form/button")).click();
		driver.findElement(By.id("id_gender2")).click();
		driver.findElement(By.id("password")).sendKeys("nandin@123");
		WebElement daydropdown = driver.findElement(By.id("days"));
		Select obj1 = new Select(daydropdown);
		obj1.selectByValue("6");
		WebElement monthdd = driver.findElement(By.id("months"));
		Select obj2 = new Select(monthdd);
		obj2.selectByIndex(9);
		WebElement yeardd = driver.findElement(By.id("years"));
		Select obj3 = new Select(yeardd);
		obj3.selectByVisibleText("1997");
		driver.findElement(By.id("newsletter")).click();
		driver.findElement(By.id("optin")).click();
		driver.findElement(By.id("first_name")).sendKeys("janapamala");
		driver.findElement(By.id("last_name")).sendKeys("j");
		driver.findElement(By.id("company")).sendKeys("Amazon");
		driver.findElement(By.id("address1")).sendKeys("plotno-109");
		driver.findElement(By.id("address2")).sendKeys("plotno-108");
		driver.findElement(By.id("country")).sendKeys("india");
		driver.findElement(By.id("state")).sendKeys("Telangana");
		driver.findElement(By.id("city")).sendKeys("Hyderabad");
		driver.findElement(By.id("zipcode")).sendKeys("500000");
		driver.findElement(By.id("mobile_number")).sendKeys("1234567890");
		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div/div/div/form/button")).click();
		String AC = driver.findElement(By.xpath("//*[@id=\"form\"]/div/div/div/h2/b")).getText();
		System.out.println(AC);
		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div/div/div/a")).click();
		String LUN = driver.findElement(By.xpath("//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[10]/a")).getText();
		System.out.println(LUN);
		driver.findElement(By.xpath("//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[3]/a")).click();
		driver.findElement(By.xpath("//*[@id=\"do_action\"]/div[1]/div/div/a")).click();
		boolean adressD = driver.findElement(By.xpath("//div[@class='alert-success alert']")).isDisplayed();
		if (adressD == true) {
			System.out.println("pass");
		} else {
			System.out.println("fail");
		}
		boolean orderD = driver.findElement(By.xpath("//*[@id=\"cart_info\"]/table/tbody")).isDisplayed();
		if (orderD == true) {
			System.out.println("pass");
		} else {
			System.out.println("fail");
		}
		driver.findElement(By.xpath("//*[@id=\"ordermsg\"]/textarea")).sendKeys("Order this product fast asap");
		driver.findElement(By.xpath("//*[@id=\"cart_items\"]/div/div[7]/a")).click();
		driver.findElement(By.xpath("//*[@id=\"payment-form\"]/div[1]/div/input")).sendKeys("nandini");
		driver.findElement(By.xpath("//*[@id=\"payment-form\"]/div[2]/div/input")).sendKeys("12345678901234567890");
		driver.findElement(By.xpath("//*[@id=\"payment-form\"]/div[3]/div[1]/input")).sendKeys("123");
		driver.findElement(By.xpath("//*[@id=\"payment-form\"]/div[3]/div[2]/input")).sendKeys("12");
		driver.findElement(By.xpath("//*[@id=\"payment-form\"]/div[3]/div[3]/input")).sendKeys("2029");
		driver.findElement(By.xpath("//*[@id=\"submit\"]")).click();
		String text = driver.findElement(By.xpath("//div[@class='alert-success alert']")).getText();
		System.out.println(text);
		driver.findElement(By.xpath("//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[5]/a")).click();
		boolean AD = driver.findElement(By.xpath("//*[@id=\"form\"]/div/div/div/h2/b")).isDisplayed();
		if (AD == true) {
			System.out.println("pass");
		} else {
			System.out.println("fail");
		}
		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div/div/div/a")).click();
	}
	@AfterTest
	public void closeapp() {
		driver.close();
	}
}
