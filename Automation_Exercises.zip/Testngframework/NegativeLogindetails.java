package testNGframework;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class NegativeLogindetails {
	WebDriver driver;

	@BeforeTest
	public void launchapp() throws Exception {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\Nandu\\Downloads\\chromedriver-win64//chromedriver.exe");
		driver = new ChromeDriver();
		driver.navigate().to("https://automationexercise.com/");
		driver.manage().window().maximize();
	}
	@Test
	public void loginN() {
		boolean homepage = driver.findElement(By.xpath("//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[1]/a"))
				.isDisplayed();
		if (homepage == true) {
			System.out.println("pass");
		} else {
			System.out.println("fail");
		}
		driver.findElement(By.xpath("//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[4]/a")).click();
		String loginact = driver.findElement(By.xpath("//*[@id=\"form\"]/div/div/div[1]/div/h2")).getText();
		System.out.println(loginact);
		driver.findElement(By.name("email")).sendKeys("nandini1999@gmail.com");
		driver.findElement(By.name("password")).sendKeys("nandini");
		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div/div[1]/div/form/button")).click();
		String incorrectEP = driver.findElement(By.xpath("//*[@id=\"form\"]/div/div/div[1]/div/form/p")).getText();
		System.out.println(incorrectEP);
	}

	@AfterTest
	public void closeapp() {
		driver.close();
	}
}
