package testNGframework;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class ContactUS {
	WebDriver driver;

	@BeforeTest
	public void launchapp() throws Exception {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\Nandu\\Downloads\\chromedriver-win64//chromedriver.exe");
		driver = new ChromeDriver();
		driver.navigate().to("https://automationexercise.com/");
		driver.manage().window().maximize();
	}

	@Test
	public void Contactus() {
		boolean homepage = driver.findElement(By.xpath("//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[1]/a"))
				.isDisplayed();
		if (homepage == true) {
			System.out.println("pass");
		} else {
			System.out.println("fail");
		}
		driver.findElement(By.xpath("//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[8]/a")).click();
		String getIT = driver.findElement(By.xpath("//*[@id=\"contact-page\"]/div[2]/div[1]/div/h2")).getText();
		System.out.println(getIT);
		driver.findElement(By.name("name")).sendKeys("nandini");
		driver.findElement(By.name("email")).sendKeys("nandini8@gmail.com");
		driver.findElement(By.name("subject")).sendKeys("product");
		driver.findElement(By.name("message")).sendKeys("products are not visible");
		driver.findElement(By.name("upload_file")).sendKeys("C:\\Users\\Nandu\\Downloads\\testing image.png");
		driver.findElement(By.name("submit")).click();
		Alert a = driver.switchTo().alert();
		a.accept();
		String text = driver.findElement(By.xpath("//*[@id=\"contact-page\"]/div[2]/div[1]/div/div[2]")).getText();
		System.out.println(text);
		driver.findElement(By.xpath("//*[@id=\"form-section\"]/a/span")).click();
		boolean HomeP = driver.findElement(By.xpath("/html/body")).isDisplayed();
		if (HomeP == true) {
			System.out.println("pass");
		} else {
			System.out.println("fail");
		}
	}

	@AfterTest
	public void closeapp() {
		driver.close();
	}
}
